import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _6dfb7bbf = () => interopDefault(import('../pages/layout/index' /* webpackChunkName: "" */))
const _8a041398 = () => interopDefault(import('../pages/home/index' /* webpackChunkName: "" */))
const _80a9734c = () => interopDefault(import('../pages/login/index' /* webpackChunkName: "" */))
const _8c4205cc = () => interopDefault(import('../pages/profile/index' /* webpackChunkName: "" */))
const _0fb6bd10 = () => interopDefault(import('../pages/settings/index' /* webpackChunkName: "" */))
const _830cb87c = () => interopDefault(import('../pages/editor/index' /* webpackChunkName: "" */))
const _0bead2a7 = () => interopDefault(import('../pages/article/index' /* webpackChunkName: "" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    components: {
      default: _6dfb7bbf
    },
    children: [{
      path: "",
      components: {
        default: _8a041398
      },
      name: "home"
    }, {
      path: "/login",
      components: {
        default: _80a9734c
      },
      name: "login"
    }, {
      path: "/register",
      components: {
        default: _80a9734c
      },
      name: "register"
    }, {
      path: "/profile/:username",
      components: {
        default: _8c4205cc
      },
      name: "profile"
    }, {
      path: "/settings",
      components: {
        default: _0fb6bd10
      },
      name: "settings"
    }, {
      path: "/editor",
      components: {
        default: _830cb87c
      },
      name: "editor"
    }, {
      path: "/article/:slug",
      components: {
        default: _0bead2a7
      },
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
